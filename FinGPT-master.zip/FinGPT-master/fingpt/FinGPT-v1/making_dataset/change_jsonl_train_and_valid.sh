python cover_alpaca2jsonl.py \
    --data_path dataset_title_train_and_valid.json \
    --save_path dataset_title_train_and_valid.jsonl