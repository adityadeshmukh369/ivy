python tokenize_dataset_rows.py \
    --jsonl_path dataset_content_train_and_valid.jsonl \
    --save_path dataset_content_train_and_valid \
    --max_seq_length 1024